#include "tensor1.h"


struct SBNN_FP_FULL
{
    
    

 t1::tensor2f fc1_weight;
 t1::tensor2f fc1_mask;
 t1::tensor1f fc1_alpha;
 t1::tensor1f fc1_bias;

 t1::tensor2f fc2_weight;
 t1::tensor2f fc2_mask;
 t1::tensor1f fc2_alpha;
 t1::tensor1f fc2_bias;
 


};

SBNN_FP_FULL SBNN_FPLoad(const char* filename);


struct SBLinear{
    t1::tensor2f weight;
    t1::tensor2f mask;
    t1::tensor1f alpha;
    t1::tensor1f bias;
};


SBNN_FP_FULL SBNN_FPLoad(const char* filename);


t1::tensor2f SBNN_FPForward(const SBNN_FP_FULL& ctx, t1::tensor2f x0);
t1::tensor2f SBNN_FPForward(t1::tensor2f x0);
t1::tensor2f SBNN_FPForward(t1::tensor2f x0,const char* weight_file);
t1::tensor2f SBNN_FPForward(t1::tensor2f*& x0,const char* weight_file);
t1::tensor2f SBNN_FPForward(const SBNN_FP_FULL& ctx, t1::tensor2f*& x0);

void print_memory(void);
