#include <iostream>

template<typename T>
inline void checkNullPointer(T*& x)
{
    if (x == nullptr) {
        std::cout << "Pointer is null" << std::endl;
    } else {
        std::cout << "Pointer is not null" << std::endl;
    }
}

class MyClass {
public:
    MyClass() {
        std::cout << "MyClass constructor" << std::endl;
    }

    ~MyClass() {
        std::cout << "MyClass destructor" << std::endl;
    }
};

template<typename T>
void deleteAndNull(T*& x){
    delete x;
	x = nullptr;
    checkNullPointer(x);
}

void m2(MyClass*& obj) {
    deleteAndNull(obj);
    std::cout<<"m2"<<std::endl;
    checkNullPointer(obj);
}

void m1(MyClass*& obj) {
    std::cout<<"m1"<<std::endl;
    m2(obj);
    std::cout<<"m1_2"<<std::endl;
    checkNullPointer(obj);
}

int main() {
    MyClass* a = new MyClass(); // Create an object and obtain a raw pointer
    m1(a); // Pass the raw pointer to m1
    std::cout << "Back in main" << std::endl;
    checkNullPointer(a);
    return 0;
}
