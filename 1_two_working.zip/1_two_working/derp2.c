#include <stdio.h>
#include <stdlib.h>

void checkNullPointer(void* x) {
    if (x == NULL) {
        printf("Pointer is null\n");
    } else {
        printf("Pointer is not null\n");
    }
}

struct MyClass {

};

void deleteAndNull(void** x) {
    free(*x);
    *x = NULL;
    checkNullPointer(*x);
}

void m2(struct MyClass** obj) {
    deleteAndNull((void**)obj);
    printf("m2\n");
    checkNullPointer(*obj);
}

void m1(struct MyClass** obj) {
    printf("m1\n");
    m2(obj);
    printf("m1_2\n");
    checkNullPointer(*obj);
}


/*
typedef struct  MyClass2 {
    
} MyClass2;


void checkNullPointer2(MyClass2* x) {
    if (x == NULL) {
        printf("Pointer is null\n");
    } else {
        printf("Pointer is not null\n");
    }
}

void deleteAndNull2(MyClass2* x) {
    free(x);
    x = NULL;
    checkNullPointer2(x);
}

void m4(MyClass2* obj) {
    deleteAndNull2(obj);
    printf("m4\n");
    checkNullPointer2(obj);
}

void m3(MyClass2* obj) {
    printf("m3\n");
    m4(obj);
    printf("m3_2\n");
    checkNullPointer2(obj);
}
*/


int main() {
    struct MyClass* a = (struct MyClass*)malloc(sizeof(struct MyClass));
    m1(&a);
    printf("Back in main\n");
    checkNullPointer(a);


    struct MyClass2* b = (struct MyClass2*)malloc(sizeof(struct MyClass2));
    m3(b);
    checkNullPointer2(b);

    return 0;
}
