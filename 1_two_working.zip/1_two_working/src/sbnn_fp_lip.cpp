#include "sbnn_fp.h"




SBLinear* load_layer(const char* weight_file,long& file_loc_offset, std::string layer_name,int row, int col)
{
     t1::model_dict* fc_dict=t1::load_layer_by_name(weight_file,layer_name,file_loc_offset);
     std::string weight = layer_name+".weight";
     std::string mask = layer_name+".mask";
     std::string alpha = layer_name+".alpha";


     SBLinear* layer = new SBLinear;
     fc_dict->load(layer->weight, weight.c_str(), col, row);
     fc_dict->load(layer->mask, mask.c_str(), col, row);
     fc_dict->load(layer->alpha, alpha.c_str(), 1);
     
     file_loc_offset=fc_dict->file_loc_offset;

     t1::deleteAndNull(fc_dict);

     return layer;
}
     
t1::tensor2f SBLinearForward(t1::tensor2f*& input, SBLinear*& layer)
{
     t1::tensor2f input_tensor=t1::tensor2f::New(input);
     t1::tensor2f weight_alpha_mask= layer->weight * (float)layer->alpha.ptr()[0] * layer->mask;
     t1::tensor2f output = t1::Linear(input_tensor, weight_alpha_mask, layer->bias);

     t1::deleteAndNull(layer);
     return output;
}

t1::tensor2f* SBLinearForwardPtr(t1::tensor2f*& input, SBLinear*& layer)
{
     t1::tensor2f input_tensor=t1::tensor2f::New(input);

     t1::tensor2f weight_alpha_mask= layer->weight * (float)layer->alpha.ptr()[0] * layer->mask;
     t1::tensor2f output = t1::Linear(input_tensor, weight_alpha_mask, layer->bias);

     t1::tensor2f* outputPtr=t1::tensor2f::New(output);
     t1::deleteAndNull(layer);
     return outputPtr;
}


t1::tensor2f* ReLU(t1::tensor2f*& input)
{
     t1::tensor2f input_tensor=t1::tensor2f::New(input);
     t1::tensor2f output = t1::ReluInplace(input_tensor);
     t1::tensor2f* outputPtr=t1::tensor2f::New(output);
     return outputPtr;
}




t1::tensor2f SBNN_FPForward(t1::tensor2f*& x0,const char* weight_file)
{
    long file_loc_offset=0;

    SBLinear* layer1=load_layer(weight_file, file_loc_offset, "fc1", 784, 512);
    t1::tensor2f* x1=SBLinearForwardPtr( x0, layer1);

    t1::tensor2f* x2 = ReLU(x1);
    
    //std::cout<<file_loc_offset<<std::endl;
    
    SBLinear* layer2=load_layer(weight_file, file_loc_offset, "fc2", 512, 10);
    t1::tensor2f x3=SBLinearForward( x2, layer2);
    return x3;
}
