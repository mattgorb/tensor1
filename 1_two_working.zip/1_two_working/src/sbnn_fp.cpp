#include "sbnn_fp.h"



SBNN_FP_FULL SBNN_FPLoad(const char* filename)
{
     SBNN_FP_FULL ctx;
     t1::model_dict dict = t1::load(filename);

     dict.load(ctx.fc1_weight, "fc1.weight", 512, 784);
     dict.load(ctx.fc1_mask, "fc1.mask", 512, 784);
     dict.load(ctx.fc1_alpha, "fc1.alpha", 1);

     dict.load(ctx.fc2_weight, "fc2.weight", 10, 512);
     dict.load(ctx.fc2_mask, "fc2.mask", 10, 512);
     dict.load(ctx.fc2_alpha, "fc2.alpha", 1);


     return ctx;
}

t1::tensor2f* SBNN_Layer1Forward(const SBNN_FP_FULL& ctx, t1::tensor2f*& input)
{
     t1::tensor2f input_tensor=t1::tensor2f::New(input);

     t1::tensor2f weight_alpha_mask_fc1= ctx.fc1_weight * (float)ctx.fc1_alpha.ptr()[0] * ctx.fc1_mask;
     t1::tensor2f x1 = t1::Linear(input_tensor, weight_alpha_mask_fc1, ctx.fc1_bias);


     t1::tensor2f x2 = t1::ReluInplace(x1);
     t1::tensor2f* out=t1::tensor2f::New(x2);
     return out;
}

t1::tensor2f SBNN_Layer2Forward(const SBNN_FP_FULL& ctx, t1::tensor2f*& input)
{
     t1::tensor2f input_tensor=t1::tensor2f::New(input);

     t1::tensor2f weight_alpha_mask_fc2= ctx.fc2_weight * (float)ctx.fc2_alpha.ptr()[0] * ctx.fc2_mask;
     t1::tensor2f x3 = t1::Linear(input_tensor, weight_alpha_mask_fc2, ctx.fc2_bias);


     return x3;
}

t1::tensor2f SBNN_FPForward(const SBNN_FP_FULL& ctx, t1::tensor2f*& x0)
{
     t1::tensor2f* x1=SBNN_Layer1Forward(ctx, x0);
     t1::tensor2f x2=SBNN_Layer2Forward(ctx, x1);
     return x2;
}